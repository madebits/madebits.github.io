// csc /r:MyInterface.dll client.cs

using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

class MyClient
{
	public static void Main()
	{
		TcpChannel m_TcpChan = new TcpChannel();
		ChannelServices.RegisterChannel(m_TcpChan);
		// note that the client makes use of Activator to get to the interface
		MyInterface m_RemoteObject = (MyInterface)
			Activator.GetObject(typeof(MyInterface),
			"tcp://127.0.0.1:9999/FirstRemote");
			TestClass test = m_RemoteObject.FunctionOne("Nish");
		test.Print();
		//Console.WriteLine();
	}
}